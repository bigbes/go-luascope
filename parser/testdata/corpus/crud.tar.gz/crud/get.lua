local checks = require('checks')
local errors = require('errors')

local call = require('crud.common.call')
local compat_warn = require('crud.common.compat_warn')
local const = require('crud.common.const')
local utils = require('crud.common.utils')
local sharding = require('crud.common.sharding')
local dev_checks = require('crud.common.dev_checks')
local schema = require('crud.common.schema')
local bucket_ref_unref = require('crud.common.sharding.bucket_ref_unref')

local GetError = errors.new_class('GetError', {capture_stack = false})

local get = {}

local GET_FUNC_NAME = 'get_on_storage'
local CRUD_GET_FUNC_NAME = utils.get_storage_call(GET_FUNC_NAME)

local function get_on_storage(space_name, key, field_names, opts)
    dev_checks('string', '?', '?table', {
        -- bucket_id is optional to support old routers.
        bucket_id = '?number|cdata',
        sharding_key_hash = '?number',
        sharding_func_hash = '?number',
        skip_sharding_hash_check = '?boolean',
        fetch_latest_metadata = '?boolean',
    })

    opts = opts or {}

    local space = box.space[space_name]
    if space == nil then
        return nil, GetError:new("Space %q doesn't exist", space_name)
    end

    local _, err = sharding.check_sharding_hash(space_name,
                                                opts.sharding_func_hash,
                                                opts.sharding_key_hash,
                                                opts.skip_sharding_hash_check)

    if err ~= nil then
        return nil, err
    end

    -- Skip bucket reference if bucket_id is not provided to support old routers.
    local ref_ok, bucket_ref_err, unref
    if opts.bucket_id ~= nil then
        ref_ok, bucket_ref_err, unref = bucket_ref_unref.bucket_refro(opts.bucket_id, space.engine)
        if not ref_ok then
            return nil, bucket_ref_err
        end
    else
        compat_warn.log_nil_bucket_id('get', space_name, space.engine)
    end

    -- add_space_schema_hash is false because
    -- reloading space format on router can't avoid get error on storage
    local result = schema.wrap_func_result(space, space.get, {
        add_space_schema_hash = false,
        field_names = field_names,
        fetch_latest_metadata = opts.fetch_latest_metadata,
    }, space, key)

    if unref ~= nil then
        local unref_ok, err_unref = unref(opts.bucket_id, space.engine)
        if not unref_ok then
            return nil, err_unref
        end
    end

    return result
end

get.storage_api = {[GET_FUNC_NAME] = get_on_storage}

-- returns result, err, need_reload
-- need_reload indicates if reloading schema could help
-- see crud.common.schema.wrap_func_reload()
local function call_get_on_router(vshard_router, space_name, key, opts)
    dev_checks('table', 'string', '?', {
        timeout = '?number',
        request_timeout = '?number',
        bucket_id = '?',
        fields = '?table',
        prefer_replica = '?boolean',
        balance = '?boolean',
        mode = '?string',
        vshard_router = '?string|table',
        fetch_latest_metadata = '?boolean',
    })

    local space, err, netbox_schema_version = utils.get_space(space_name, vshard_router, {
        timeout = opts.timeout,
        read_only = opts.mode ~= 'write',
    })
    if err ~= nil then
        return nil, GetError:new("An error occurred during the operation: %s", err), const.NEED_SCHEMA_RELOAD
    end
    if space == nil then
        return nil, GetError:new("Space %q doesn't exist", space_name), const.NEED_SCHEMA_RELOAD
    end

    if box.tuple.is(key) then
        key = key:totable()
    end

    local sharding_data, err, need_reload = sharding.key_set_and_return_bucket_id(
        vshard_router, space, key, opts.bucket_id)
    if err ~= nil then
        return nil, err, need_reload
    end

    local get_on_storage_opts = {
        bucket_id = sharding_data.bucket_id,
        sharding_func_hash = sharding_data.sharding_func_hash,
        sharding_key_hash = sharding_data.sharding_key_hash,
        skip_sharding_hash_check = sharding_data.skip_sharding_hash_check,
        fetch_latest_metadata = opts.fetch_latest_metadata,
    }

    local mode = opts.mode or 'read'

    local call_opts = {
        mode = mode,
        prefer_replica = opts.prefer_replica,
        balance = opts.balance,
        timeout = opts.timeout,
        request_timeout = mode == 'read' and opts.request_timeout or nil,
    }

    local storage_result, err = call.single(vshard_router,
        sharding_data.bucket_id, CRUD_GET_FUNC_NAME,
        {space_name, key, opts.fields, get_on_storage_opts},
        call_opts
    )

    if err ~= nil then
        local err_wrapped = GetError:new("Failed to call get on storage-side: %s", err)

        if sharding.result_needs_sharding_reload(err) then
            return nil, err_wrapped, const.NEED_SHARDING_RELOAD
        end

        return nil, err_wrapped
    end

    if storage_result.err ~= nil then
        return nil, GetError:new("Failed to get: %s", storage_result.err)
    end

    local tuple = storage_result.res

    -- protect against box.NULL
    if tuple == nil then
        tuple = nil
    end

    if opts.fetch_latest_metadata == true then
        -- This option is temporary and is related to [1], [2].
        -- [1] https://github.com/tarantool/crud/issues/236
        -- [2] https://github.com/tarantool/crud/issues/361
        space = utils.fetch_latest_metadata_when_single_storage(space, space_name, netbox_schema_version,
                                                                vshard_router, opts, storage_result.storage_info)
    end

    return utils.format_result({tuple}, space, opts.fields)
end

--- Get tuple from the specified space by key
--
-- @function call
--
-- @param string space_name
--  A space name
--
-- @param key
--  Primary key value
--
-- @tparam ?number opts.timeout
--  Function call timeout
--
-- @tparam ?number opts.request_timeout
--  vshard call request_timeout
--  default is the same as opts.timeout
--
-- @tparam ?number|cdata opts.bucket_id
--  Bucket ID. If omitted, calculated from the primary key using the space's
--  configured sharding key and function.
--
-- @tparam ?string opts.mode
--  VShard call mode: 'read' (default) or 'write'. Write mode calls the master.
--
-- @tparam ?boolean opts.prefer_replica
--  Call on replica if it's possible
--
-- @tparam ?boolean opts.balance
--  Use replica according to round-robin load balancing
--
-- @tparam ?string|table opts.vshard_router
--  Cartridge vshard group name or vshard router instance.
--  Set this parameter if your space is not a part of the
--  default vshard cluster.
--
-- @return[1] object
-- @treturn[2] nil
-- @treturn[2] table Error description
--
function get.call(space_name, key, opts)
    checks('string', '?', {
        timeout = '?number',
        request_timeout = '?number',
        bucket_id = '?',
        fields = '?table',
        prefer_replica = '?boolean',
        balance = '?boolean',
        mode = '?string',
        vshard_router = '?string|table',
        fetch_latest_metadata = '?boolean',
    })

    opts = opts or {}

    local vshard_router, err = utils.get_vshard_router_instance(opts.vshard_router)
    if err ~= nil then
        return nil, GetError:new(err)
    end

    return schema.wrap_func_reload(vshard_router, sharding.wrap_method, call_get_on_router,
                                   space_name, key, opts)
end

return get
